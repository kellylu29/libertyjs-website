<?php ?>

<div class="ljs2017-footer__container">
	<img
		class="ljs2017-footer__logo"
		src="<?php echo get_stylesheet_directory_uri(); ?>/img/ljs2017-primary-logo-black-yellow.png"
		alt="LibertyJS Logo">
	<div class="ljs2017-footer__info-location">
		NOVEMBER 16 &amp; 17 • PHILADELPHIA, USA
	</div>
</div>

<?php wp_footer(); ?>

</body>
</html>
