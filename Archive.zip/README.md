# LibertyJS 2017

This is the theme for LibertyJS 2017. It is adapted from the WooConf.com 2017
theme design by Gary Murray.

## Installation

1. Have node
2. `npm install`
3. Type `gulp` to build
4. Type `gulp watch` to build and then watch
5. Type `gulp imagemin` to optimize images
6. Type `gulp updatefontawesome` to update font-awesome after an npm install
